/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Vijay
 */
@Entity
@Table(name = "bookrecord", catalog = "library", schema = "")
@NamedQueries({
    @NamedQuery(name = "Bookrecord.findAll", query = "SELECT b FROM Bookrecord b")
    , @NamedQuery(name = "Bookrecord.findByBookid", query = "SELECT b FROM Bookrecord b WHERE b.bookid = :bookid")
    , @NamedQuery(name = "Bookrecord.findByBookname", query = "SELECT b FROM Bookrecord b WHERE b.bookname = :bookname")
    , @NamedQuery(name = "Bookrecord.findByCategory", query = "SELECT b FROM Bookrecord b WHERE b.category = :category")
    , @NamedQuery(name = "Bookrecord.findByAuthor", query = "SELECT b FROM Bookrecord b WHERE b.author = :author")
    , @NamedQuery(name = "Bookrecord.findByPublisher", query = "SELECT b FROM Bookrecord b WHERE b.publisher = :publisher")
    , @NamedQuery(name = "Bookrecord.findByDepartment", query = "SELECT b FROM Bookrecord b WHERE b.department = :department")
    , @NamedQuery(name = "Bookrecord.findByEdition", query = "SELECT b FROM Bookrecord b WHERE b.edition = :edition")})
public class Bookrecord implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "bookid")
    private Integer bookid;
    @Column(name = "bookname")
    private String bookname;
    @Column(name = "category")
    private String category;
    @Column(name = "author")
    private String author;
    @Column(name = "publisher")
    private String publisher;
    @Column(name = "department")
    private String department;
    @Column(name = "edition")
    private String edition;

    public Bookrecord() {
    }

    public Bookrecord(Integer bookid) {
        this.bookid = bookid;
    }

    public Integer getBookid() {
        return bookid;
    }

    public void setBookid(Integer bookid) {
        Integer oldBookid = this.bookid;
        this.bookid = bookid;
        changeSupport.firePropertyChange("bookid", oldBookid, bookid);
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        String oldBookname = this.bookname;
        this.bookname = bookname;
        changeSupport.firePropertyChange("bookname", oldBookname, bookname);
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        String oldCategory = this.category;
        this.category = category;
        changeSupport.firePropertyChange("category", oldCategory, category);
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        String oldAuthor = this.author;
        this.author = author;
        changeSupport.firePropertyChange("author", oldAuthor, author);
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        String oldPublisher = this.publisher;
        this.publisher = publisher;
        changeSupport.firePropertyChange("publisher", oldPublisher, publisher);
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        String oldDepartment = this.department;
        this.department = department;
        changeSupport.firePropertyChange("department", oldDepartment, department);
    }

    public String getEdition() {
        return edition;
    }

    public void setEdition(String edition) {
        String oldEdition = this.edition;
        this.edition = edition;
        changeSupport.firePropertyChange("edition", oldEdition, edition);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (bookid != null ? bookid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bookrecord)) {
            return false;
        }
        Bookrecord other = (Bookrecord) object;
        if ((this.bookid == null && other.bookid != null) || (this.bookid != null && !this.bookid.equals(other.bookid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Classes.Bookrecord[ bookid=" + bookid + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
